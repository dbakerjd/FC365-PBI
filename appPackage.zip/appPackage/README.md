# App Package

Your "app package" is used to publish your app configuration to Teams by manually using the "Upload a custom app" from the app gallery in Teams. 

This package can also be used to manually publish your app to the Teams store or your organization.

## Visual Studio Code Teams extension usage
If you created a project using the Teams extension in Visual Studio code you do not need the contents of this folder.  Your configuration will be saved into Teams App Studio and can be configured through the Teams extension or by using the Teams App Studio app within Teams.